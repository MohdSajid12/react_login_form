import './App.css';
import AuthForm from './AuthForm'

function App() {
  return (
      <div><AuthForm/></div>
  );
}

export default App;
