import React, { useState } from 'react';

function AuthForm()
    {
     const[islogin ,setIsLogin] = useState(true);
        return(
            <div className='container'>
                <div className='form-container'>
                    <div className='form-toggle'>
                        <button className={islogin ? 'active' : ""} onClick={ ()=> setIsLogin(true)}>Login</button>
                        <button className={!islogin ? 'active' : ""} onClick={() => setIsLogin(false)}>Signup</button>
                    </div>
                {islogin ? <>
                    <div className='form'>
                       <h2>Login form</h2>
                       <input type="email" placeholder='email'></input>
                       <input type="password" placeholder='password'></input>
                       <a href='#'>Forgot Password</a>
                       <button>Login</button>
                       <p>Not a Member ? <a href="#" onClick={ ()=> setIsLogin(false)}>Signup now</a></p>
                    </div>
                    </> : 
                        <>
                        <div className='form'>
                           <h2>Signup form</h2>
                           <input type="email" placeholder='email'></input>
                           <input type="password" placeholder='password'></input>
                           <input type="password" placeholder='confirm password'></input>
                           <button>Signup</button>
                        </div>
                        </>                   
                    }
                </div>
            </div>
        )
    }

export default AuthForm;